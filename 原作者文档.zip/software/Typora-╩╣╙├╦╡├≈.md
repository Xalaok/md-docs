---
title: 'Typora 使用说明'
linktitle: ""
date: "2019-06-12T21:35:29+08:00"
lastmod: "2020-10-05T21:35:29+08:00"
toc: true
type: book
weight: 2
---



## 快捷键

* [Shortcut Keys](http://support.typora.io/Shortcut-Keys/)

使用快捷键能极大提高写作效率。

### 文件

| 功能                 | 热键（Windows / Linux） | 热键（macOS）        |
| :------------------- | :---------------------- | -------------------- |
| 新                   | Ctrl + N                | Command + N.         |
| 新窗户               | Ctrl + Shift + N        | Command + Shift + N. |
| **新标签**           | *（不支持）*            | Command + T.         |
| 打开                 | Ctrl + O                | Command + O.         |
| **快速打开**         | Ctrl + P                | Command + Shift + O. |
| 重新打开已关闭的文件 | Ctrl + Shift + T        | Command + Shift + T. |
| 保存                 | Ctrl + S                | Command + S.         |
| 另存为/重复          | Ctrl + Shift + S        | Command + Shift + S. |
| 偏爱                 | Ctrl + ，               | Command +，          |
| **关**               | Ctrl + W                | Command + W          |

### 编辑

| 功能                                | 热键（Windows / Linux）    | 热键（macOS）                       |
| :---------------------------------- | :------------------------- | ----------------------------------- |
| 新段落                              | 输入                       | 输入                                |
| **换行**                            | Shift + Enter              | Shift + Enter                       |
| 剪切                                | Ctrl + X                   | Command + X.                        |
| 复制                                | Ctrl + C                   | Command + C.                        |
| 粘贴                                | Ctrl + V                   | Command + V.                        |
| 复制为Markdown                      | Ctrl + Shift + C           | Command + Shift + C.                |
| **粘贴为纯文本**                    | Ctrl + Shift + V           | Command + Shift + V.                |
| 全选                                | Ctrl + A                   | Command + A.                        |
| 选择行/句子 选择行（在表格中）      | Ctrl + L                   | Command + L.                        |
| 删除行（在表中）                    | Ctrl + Shift + Backspace   | Command + Shift + Backspace         |
| 选择样式范围 选择单元格（在表格中） | Ctrl + E                   | Command + E.                        |
| 选择Word                            | Ctrl + D                   | Command + D.                        |
| 删除Word                            | Ctrl + Shift + D           | Command + Shift + D.                |
| 跳到顶部                            | Ctrl + Home                | Command +↑                          |
| 跳转到选择                          | Ctrl + J                   | Command + J                         |
| 跳到Bottom                          | Ctrl + End                 | Command +↓                          |
| **找**                              | Ctrl + F                   | Command + F.                        |
| 找下一个                            | F3 / 回车                  | Command + G / Enter                 |
| 找到上一个                          | Shift + F3 / Shift + Enter | Command + Shift + G / Shift + Enter |
| **更换**                            | Ctrl + H                   | Command + H.                        |

### 段落

| 功能         | 热键（Windows / Linux） | 热键（macOS）            |
| :----------- | :---------------------- | ------------------------ |
| 标题1到6     | Ctrl + 1/2/3/4/5/6      | Command + 1/2/3/4/5/6    |
| 段落         | Ctrl + 0                | 命令+ 0                  |
| 提高标题级别 | Ctrl + =                | 命令+ =                  |
| 降低标题级别 | Ctrl + -                | 命令+ -                  |
| **表**       | Ctrl + T                | Command + Option + T.    |
| 代码围栏     | Ctrl + Shift + K        | Command + Option + C.    |
| 数学块       | Ctrl + Shift + M        | Command + Option + B.    |
| 引用         | Ctrl + Shift + Q        | Command + Option + Q.    |
| **订购清单** | Ctrl + Shift + [        | Command + Option + O.    |
| **无序列表** | Ctrl + Shift +]         | Command + Option + U.    |
| 缩进         | Ctrl + [ / Tab          | Command + [/ Tab         |
| 减少缩进     | Ctrl +] / Shift + Tab   | Command +] / Shift + Tab |

### 格式

| 功能       | 热键（Windows / Linux） | 热键（macOS）         |
| :--------- | :---------------------- | --------------------- |
| 强大       | Ctrl + B                | Command + B.          |
| 重点       | Ctrl + I                | 命令+我               |
| 强调       | Ctrl + U                | Command + U.          |
| **码**     | Ctrl + Shift + \`       | Ctrl + Shift + \`     |
| 罢工       | Alt + Shift + 5         | Control + Shift +`    |
| **超链接** | Ctrl + K                | Command + K.          |
| **图片**   | Ctrl + Shift + I        | Command + Control + I |
| 清除格式   | Ctrl + \\               | 命令+                 |

### 视图

| 功能                      | 热键（Windows / Linux） | 热键（macOS）         |
| :------------------------ | :---------------------- | --------------------- |
| 切换补充工具栏            | Ctrl + Shift + L.       | Command + Shift + L.  |
| 大纲                      | Ctrl + Shift + 1        | Command + Control + 1 |
| 用品                      | Ctrl + Shift + 2        | Command + Control + 2 |
| **文件树**                | Ctrl + Shift + 3        | Command + Control + 3 |
| **源代码模式**            | Ctrl + /                | 命令+ /               |
| Fouus模式                 | F8                      | F8                    |
| 打字机模式                | F9                      | F9                    |
| Toggler全屏               | F11                     | Command + Option + F. |
| 真实大小                  | Ctrl + Shift + 0        | *（不支持）*          |
| **放大**                  | Ctrl + Shift + =        | *（不支持）*          |
| **缩小**                  | Ctrl + Shift + -        | *（不支持）*          |
| 在打开的Documnets之间切换 | Ctrl + Tab              | 命令+`                |
| 切换DevTools              | Ctrl + Shift + I        | -                     |



## 配置插入图片

> 合理的软件配置也能提高写作效率。

在用 Typora 插入图片的时候，会自动插入全路径，

我们可以插入后修改，但是这样在写文章的时候无法预览图片，如何既能符合发布的格式，又能在本地预览呢？

我们在偏好设置里，勾选“优先使用相对路径”，这样就能展示相对路径了。

同时，在插入图片时增加一个动作，复制到当前路径下的 filename 目录下，这样就不用提前把图片放到目录下，直接随意插入就能符合发布格式了。







## See also

* [Typora 完全使用详解](https://sspai.com/post/54912)
* [Typora - 不要太棒的 Markdown 编辑器](https://zhuanlan.zhihu.com/p/44998516)
* [Typora 常用的快捷键【摘自官网】](https://www.cnblogs.com/gxh195/p/10657200.html)

