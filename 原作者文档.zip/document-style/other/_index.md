---
# Title, summary, and page position.
linktitle: 
summary: Learn how to use Academic's docs layout for publishing online courses, software documentation, and tutorials.
weight: 6
icon: book-reader
icon_pack: fas

# Page metadata.
title: 其他
date: "2018-09-09T00:00:00Z"
type: book  # Do not modify.
toc: false
---

