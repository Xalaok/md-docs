---
# Title, summary, and page position.
linktitle: 
summary: 
weight: 1
icon: book-reader
icon_pack: fas

# Page metadata.
title: 详细版
date: "2018-09-09T00:00:00Z"
type: book  # Do not modify.
---

更加详细的 Markdown 语法说明。

相关网站：

* [Markdown Guide](https://www.markdownguide.org/basic-syntax/#overview)（教学网站）
* [Markdown 语法说明 (简体中文版) ](https://github.com/appinncom/Markdown-Syntax-CN/)
* [Markdown 编辑器语法指南](https://segmentfault.com/markdown)

