---
title: "Markdown 任务列表"
linktitle: ""
date: "2019-06-12T21:35:29+08:00"
lastmod: "2019-10-05T21:35:29+08:00"
toc: false
type: book
weight: 8
---

代码：

```markdown
- [ ] a task list item
  - [x] completed
  - [ ] incomplete
- [ ] list syntax required
- [x] completed
```

显示效果：

- [ ] a task list item
  - [x] completed
  - [ ] incomplete
- [ ] list syntax required
- [x] completed

